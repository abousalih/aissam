package com.ginec;

import com.ginec.poo.Voiture;

import java.util.Date;

public class jPOO {
    //Programmation Orientée Object
    //Object Oriented Programing
    // Class  ==> Model (Vehicule)
    // Object ==> Instance (Exemplaire) v1:ford focus, reed, immat :5454545FF44
    //v1 est oblet de type Vehicule

    // Regle de POO : Tout est object
    // Un Objet = Ensemble d'attributs (Identité+ Proprietes + Methodes)

    Voiture v1=new Voiture();


}
