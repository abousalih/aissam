package com.ginec.poo;

import com.ginec.poo.Vehicule;

public class Camion extends Vehicule {

    private double charge;

    public void accelerer(){
    }
}
