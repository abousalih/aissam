package com.ginec.poo;

import java.util.Date;

public class TestPoo {
    public static void main(String[] args) {
        Vehicule v1; // Declaration d'un objet de type v1 (Reference d'objet Voiture)

        v1 = new Vehicule("Toyota", new Date(), 120000, 120);
        // Instanciation (Creation, Initialisation ) de l'objet v1 avec des valeurs par defauts
        // Voiture() Le constructeur de la classe Voiture : Methode permettant d'instancier un objet
        // Les valeurs par defauts: String ==>Chaine vide
        //int,double, float ==>0
        //Date ==> 01/01/01

        //v1.marque="Ford";
        // v1.setMarque("Ford");

        //v1.dateSortie=new Date();
        //v1.nbrPlace=-6;

        // Pour simplifier
        /*Vehicule v2 = new Vehicule(); // Declaration et instanciation via le conxtructeur par defaut
        v2.prix = 20;
        System.out.println(v1.getMarque());
        System.out.println(v1.getVitesse());
        System.out.println(v1.getDateSortie());
        // System.out.println(v1.prix);

        //System.out.println(v2);


        Vehicule v3 = new Vehicule("Nissan", 120);
        System.out.println(v3.getMarque());
        System.out.println(v3.getVitesse());

        Voiture vo1 = new Voiture();

        vo1.setMarque("Ford");
        vo1.prix = 10;

        System.out.println(vo1.getMarque());
        System.out.println(vo1.prix);
        //System.out.println(vo1.vitesse);*/

        System.out.println(v1);
        //System.out.println(v1.toString());

        //System.out.println(v1.somme(10,20));

        Voiture v2=new Voiture();

        System.out.println(v1.somme(20,30));
        System.out.println(v2.somme(20,30));

        Voiture v3=new Voiture("Ford", new Date(), 120000, 120,6);
        System.out.println(v3);
    }
}
