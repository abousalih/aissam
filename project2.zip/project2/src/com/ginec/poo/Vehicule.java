package com.ginec.poo;


import java.util.Date;

public class Vehicule {

    // Les Attributs

    private String marque;
    private Date dateSortie;
    private double prix;
    private double vitesseMax;

    public String getMarque() {
        return marque;
    }

    public void setMarque(String marque) {
        this.marque = marque;
    }

    public Date getDateSortie() {
        return dateSortie;
    }

    public void setDateSortie(Date dateSortie) {
        this.dateSortie = dateSortie;
    }

    public double getPrix() {
        return prix;
    }

    public void setPrix(double prix) {
        this.prix = prix;
    }

    public double getVitesseMax() {
        return vitesseMax;
    }

    public void setVitesseMax(double vitesseMax) {
        this.vitesseMax = vitesseMax;
    }

    // Les metodes

    public void accelere(){
        this.vitesseMax =this.vitesseMax +10;
    }

    public void ralenti(){
        this.vitesseMax =this.vitesseMax -10;
    }

    public void stop(){
        this.vitesseMax =0;
    }

    public Vehicule() {
    }

    public Vehicule(String marque, Date dateSortie, double prix, double vitesseMax) {
        this.marque = marque;
        this.dateSortie = dateSortie;
        this.prix = prix;
        this.vitesseMax = vitesseMax;
    }

    //La methode toString() est la  methode par defaut
    // public String toString(){} : La signature de la methode toString()
    // @Override : Annotation
    @Override
    public String toString() {
        //Le corps  de la methode ou la definition l'implementation
        return "marque='" + marque + '\'' +
                ", dateSortie=" + dateSortie +
                ", prix=" + prix +
                ", vitesse=" + vitesseMax ;
    }

    //public int somme(int a,int b){}
    public int somme(int a,int b){
        return a+b;
    }



}
