package com.ginec;

import java.util.Scanner;

public class jApp3 {
    public static void main(String[] args) {
        //i++ <==>i=1+1
        //i+=2 <==>i=i+2

        /*for (int i = 1; i <= 10; i++) {
            System.out.println("i = " + i);
            System.out.println("Hello....");
        }
        System.out.println("It's my first Java App...");*/

        Scanner scanner = new Scanner(System.in);

        int x;
        x=10;
        x=20;



        System.out.println("Taper un nombre entre 10 et 20");
        x = scanner.nextInt();

       /* while (x != 15) {
            if (x < 15) {
                System.out.println("Non, Taper un nombre plus grand");
            } else {
                System.out.println("Non, Taper un nombre plus petit");
            }
            x = scanner.nextInt();
        }*/


        do {
            if (x < 15) {
                System.out.println("Non, Taper un nombre plus grand");
            } else {
                System.out.println("Non, Taper un nombre plus petit");
            }
            x = scanner.nextInt();
        } while (x != 15);

        System.out.println("Bravo fin de test...");




    }
}
